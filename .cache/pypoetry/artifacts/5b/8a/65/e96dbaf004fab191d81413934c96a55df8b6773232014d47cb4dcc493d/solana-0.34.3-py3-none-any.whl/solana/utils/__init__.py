"""Utility functions for solanaweb3."""
